-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 03 2012 г., 16:30
-- Версия сервера: 5.5.27-log
-- Версия PHP: 5.3.16

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `dd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dt_create` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_remove` tinyint(1) NOT NULL DEFAULT '0',
  `k_user` bigint(20) NOT NULL DEFAULT '0',
  `s_name` tinyblob NOT NULL,
  `s_adress` blob NOT NULL,
  `s_phone` tinyblob NOT NULL,
  `s_email` tinyblob NOT NULL,
  `s_personnel` tinyblob NOT NULL,
  `s_description` blob NOT NULL,
  `s_need` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k_user` (`k_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `content`
--

INSERT INTO `content` (`id`, `dt_create`, `is_active`, `is_remove`, `k_user`, `s_name`, `s_adress`, `s_phone`, `s_email`, `s_personnel`, `s_description`, `s_need`) VALUES
(1, '0000-00-00 00:00:00', 0, 0, 0, 0x74657374, 0x74657374, 0x747731313131, 0x313233323133, 0x3132333132, 0x6564717765, 0x717765717765),
(2, '0000-00-00 00:00:00', 1, 1, 0, 0x77736571, 0x617364617364, 0x717765717765, 0x7177657177, 0x7177657177, 0x7177657177, 0x717765717765),
(3, '2012-10-07 00:57:38', 0, 0, 2, 0xd09dd0b0d0b7d0b2d0b0d0bdd0b8d0b52033, 0xd183d0bb20d090d180d182d0b5d0bcd0b0, 0x31323331323331323331, 0x656d61696c40656d61696c, 0xd09cd183d0b6d0b8d0ba, 0xd0b1d0bbd0b020d0b1d0bbd0b020d0b1d0bbd0b0, 0xd0bdd183d0b6d0bdd0be),
(4, '2012-10-07 12:08:53', 0, 0, 3, 0xd0a2d0b5d181d182203132333132, 0xd090d0b4d180d0b5d181, 0xd182d0b5d0bbd0b5d184d0bed0bd, 0x656d61696c40656d61696c, 0xd0a7d0b5d0bbd0bed0b2d0b5d0ba, 0xd0bed0bfd0b8d181d0b0d0bdd0b8d0b5, 0xd0bdd183d0b6d0bdd0be);

-- --------------------------------------------------------

--
-- Структура таблицы `passport_profiles`
--

CREATE TABLE IF NOT EXISTS `passport_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `s_phone` blob NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `passport_profiles`
--

INSERT INTO `passport_profiles` (`user_id`, `first_name`, `last_name`, `s_phone`) VALUES
(1, 'Administrator', 'Admin', ''),
(2, 'Простой', 'Юзер', 0x30393531313131313131),
(3, 'Другой простой', 'Юзер', 0x30393531313131313131);

-- --------------------------------------------------------

--
-- Структура таблицы `passport_profiles_fields`
--

CREATE TABLE IF NOT EXISTS `passport_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` text,
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` text,
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `passport_profiles_fields`
--

INSERT INTO `passport_profiles_fields` (`id`, `varname`, `title`, `field_type`, `field_size`, `field_size_min`, `required`, `match`, `range`, `error_message`, `other_validator`, `default`, `widget`, `widgetparams`, `position`, `visible`) VALUES
(1, 'first_name', 'First Name', 'VARCHAR', 255, 3, 2, '', '', 'Incorrect First Name (length between 3 and 50 characters).', '', '', '', '', 1, 3),
(2, 'last_name', 'Last Name', 'VARCHAR', 255, 3, 2, '', '', 'Incorrect Last Name (length between 3 and 50 characters).', '', '', '', '', 2, 3),
(3, 's_phone', 'Контактный телефон', 'BLOB', 0, 0, 1, '', '', 'Введите, пожалуйста, контактный номер', '', '', '', '', 3, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `passport_users`
--

CREATE TABLE IF NOT EXISTS `passport_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  UNIQUE KEY `user_email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `passport_users`
--

INSERT INTO `passport_users` (`id`, `username`, `password`, `email`, `activkey`, `superuser`, `status`, `create_at`, `lastvisit_at`) VALUES
(1, 'stas', 'eece3f48c15711af17b04759d1bb733e', 'webmaster@example.com', '7eedf051e456de612aa92d76f34a8120', 1, 1, '2012-09-29 12:22:43', '2012-10-12 18:10:23'),
(2, 'simple_user', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'stas.developer@gmail.com', '9045c29ad6c3c8c4157480b9d529e3d6', 0, 1, '2012-09-29 13:11:16', '2012-10-06 21:56:38'),
(3, 'another_user', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'stas.programmer@gmail.com', '13a13dd510b7310373333e66ceb94f5d', 0, 1, '2012-10-07 08:50:31', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_migration`
--

CREATE TABLE IF NOT EXISTS `tbl_migration` (
  `version` varchar(255) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tbl_migration`
--

INSERT INTO `tbl_migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1348921279),
('m110805_153437_installYiiUser', 1348921364),
('m110810_162301_userTimestampFix', 1348921365);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `passport_profiles`
--
ALTER TABLE `passport_profiles`
  ADD CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `passport_users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
